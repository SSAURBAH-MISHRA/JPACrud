package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.FeedbackNotSavedException;
import com.capgemini.exception.NoFeedbackFoundException;

public interface FeedbackService {
	public Trainer addFeedback(Trainer trainer) throws FeedbackNotSavedException;

	public HashMap<Integer, Trainer> getTrainerList(int rating) throws NoFeedbackFoundException;

}
