package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.exception.FeedbackNotSavedException;
import com.capgemini.exception.NoFeedbackFoundException;

public class FeedbackServiceImpl implements FeedbackService {

	private FeedbackDAO feedbackDAO;

	public FeedbackServiceImpl(FeedbackDAO feedbackDAO) {
		super();
		this.feedbackDAO = feedbackDAO;
	}

	@Override
	public Trainer addFeedback(Trainer trainer) throws FeedbackNotSavedException {
		if (feedbackDAO.addFeedback(trainer)) {
			return trainer;
		} else {
			throw new FeedbackNotSavedException();
		}

	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws NoFeedbackFoundException {
		if (feedbackDAO.getTrainerList(rating).size() == 0) {
			throw new NoFeedbackFoundException();
		} else {
			return feedbackDAO.getTrainerList(rating);
		}

	}

}
