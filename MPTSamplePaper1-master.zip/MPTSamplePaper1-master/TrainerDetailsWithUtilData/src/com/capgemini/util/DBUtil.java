package com.capgemini.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import com.capgemini.beans.Trainer;

public class DBUtil {

	private static HashMap<Integer, Trainer> feedbackList = new HashMap<>();
	private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

	static {
		// Already Existing Data
		feedbackList.put(141, new Trainer("Smitha", "Java", LocalDate.parse("13-03-2000", formatter),
				LocalDate.parse("10-04-2000", formatter), 5));
		feedbackList.put(122, new Trainer("Smitha", "Java", LocalDate.parse("01-01-2001", formatter),
				LocalDate.parse("10-01-2000", formatter), 4));
		feedbackList.put(143, new Trainer("Smitha", "Java", LocalDate.parse("13-10-2001", formatter),
				LocalDate.parse("23-10-2001", formatter), 3));

	}

	public static int generateId() {
		int id = (int) (Math.random() * 1000);
		return id;
	}

	public static HashMap<Integer, Trainer> getFeedback() {
		return feedbackList;
	}

}
