package com.capgemini.exception;

public class FeedbackNotSavedException extends Exception {

	private static final long serialVersionUID = 1L;

	@Override
	public String getMessage() {

		return "Connection Problem with Database";
	}

}
