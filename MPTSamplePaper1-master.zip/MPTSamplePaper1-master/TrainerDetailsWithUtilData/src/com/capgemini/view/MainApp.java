package com.capgemini.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.FeedbackDAOImpl;
import com.capgemini.exception.FeedbackNotSavedException;
import com.capgemini.exception.NoFeedbackFoundException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class MainApp {
	// validation purpose
	// try to make different method for each case
	private static FeedbackDAO feedbackDAO = new FeedbackDAOImpl();
	private static FeedbackService feedbackServiceImpl = new FeedbackServiceImpl(feedbackDAO);
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int choice = 0;
		while (true) {
			System.out.println("-----------------------Main Menu-------------------------");
			System.out.println("1.Enter the Feedback of the Trainer");
			System.out.println("2.Getting Feddback from the database");
			System.out.println("3.exit");
			System.out.println("Please Enter the choice");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				insertFeedback();
				break;
			case 2:
				displayFeedback();
				break;
			case 3:
				sc.close();
				System.exit(0);
				break;
			default:
				System.out.println("You have enterd an invalid Input");
			}

		}

	}

	public static void insertFeedback() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		Trainer trainer = new Trainer();
		System.out.println("Enter the name of the Trainer");
		sc.nextLine();
		String name = sc.nextLine();
		while ((name == null) || (!(Pattern.matches("[a-z,A-Z, ]+", name)))) {
			System.out.println("Pleasae Enter a valid name");
			name = sc.nextLine();
		}
		trainer.setName(name);
		System.out.println("Enter the name of the course");
		String courseName = sc.nextLine();
		trainer.setCourseName(courseName);
		System.out.println("Enter the startDate in (dd-mm-yyyy) format");
		String startDate = sc.nextLine();
		while (!dateValidate(startDate)) {
			System.err.println("You have Entered an Invalid date");
			System.out.println("Please Enter a valid date");
			startDate = sc.nextLine();
		}

		trainer.setStartDate(LocalDate.parse(startDate, formatter));
		System.out.println("Enter the endDate in (dd-mm-yyyy) format");
		String endDate = sc.nextLine();
		while (!dateValidate(endDate)) {
			System.err.println("You have Entered an Invalid date");
			System.out.println("Please Enter a valid date");
			endDate = sc.nextLine();
		}
		trainer.setEndDate(LocalDate.parse(endDate, formatter));
		System.out.println("Enter the Rating");
		int rating = sc.nextInt();
		trainer.setRating(rating);
		while (!((rating >= 0) && (rating < 6))) {
			System.out.println("Please enter Rating between 0 to 5");
			rating = sc.nextInt();
		}
		try {
			feedbackServiceImpl.addFeedback(trainer);
		} catch (FeedbackNotSavedException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Feedback is Saved in the database");
	}

	public static void displayFeedback() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		System.out.println("Enter the Rating");
		int rating = sc.nextInt();
		try {
			HashMap<Integer, Trainer> feedbackList = feedbackServiceImpl.getTrainerList(rating);
			for (Entry<Integer, Trainer> feedback : feedbackList.entrySet()) {
				Trainer trainer = feedback.getValue();
				System.out.println("Trainer name:" + trainer.getName() + " Course Name:" + trainer.getCourseName()
						+ " Start Date" + trainer.getStartDate().format(formatter) + " End Date"
						+ trainer.getEndDate().format(formatter) + " Rating:" + trainer.getRating());
			}
		} catch (NoFeedbackFoundException e) {
			System.err.println(e.getMessage());
		}

	}

	public static boolean dateValidate(String date) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-uuuu", Locale.US)
				.withResolverStyle(ResolverStyle.STRICT);
		try {

			LocalDate.parse(date, formatter);
			return true;
		} catch (Exception e) {

			return false;
		}

	}

}
