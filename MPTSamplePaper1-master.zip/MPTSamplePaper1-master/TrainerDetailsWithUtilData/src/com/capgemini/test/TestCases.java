package com.capgemini.test;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.FeedbackDAOImpl;
import com.capgemini.exception.FeedbackNotSavedException;
import com.capgemini.exception.NoFeedbackFoundException;
import com.capgemini.service.FeedbackService;
import com.capgemini.service.FeedbackServiceImpl;

public class TestCases {
	private static FeedbackDAO feedbackDAO;
	private static FeedbackService feedbackServiceImpl;
	private static DateTimeFormatter formatter;

	@Before
	public void setUp() throws Exception {
		feedbackDAO = new FeedbackDAOImpl();
		feedbackServiceImpl = new FeedbackServiceImpl(feedbackDAO);
		formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	}

	@Test
	public void whenFeedbackIsSuccessfullyAddedToDatabase() throws FeedbackNotSavedException {

		Trainer trainer = new Trainer("krishan", "Java", LocalDate.parse("16-09-1998", formatter),
				LocalDate.parse("18-02-1999", formatter), 5);
		assertEquals(trainer, feedbackServiceImpl.addFeedback(new Trainer("krishan", "Java",
				LocalDate.parse("16-09-1998", formatter), LocalDate.parse("18-02-1999", formatter), 5)));
	}

	@Test(expected = com.capgemini.exception.NoFeedbackFoundException.class)
	public void whenCorrespondingRatingIsNotInDatabase() throws NoFeedbackFoundException {
		feedbackServiceImpl.getTrainerList(1);
	}

	@Test
	public void whenFeedbackDataIsFetchedSuccessfully() throws NoFeedbackFoundException {
		Trainer trainer = new Trainer("Smitha", "Java", LocalDate.parse("13-10-2001", formatter),
				LocalDate.parse("23-10-2001", formatter), 3);
		assertEquals(trainer, feedbackServiceImpl.getTrainerList(3).get(143));
	}

}
