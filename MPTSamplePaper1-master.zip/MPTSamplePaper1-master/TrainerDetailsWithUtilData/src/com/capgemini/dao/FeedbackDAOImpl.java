package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map.Entry;

import com.capgemini.beans.Trainer;
import com.capgemini.util.DBUtil;

public class FeedbackDAOImpl implements FeedbackDAO {

	@Override
	public boolean addFeedback(Trainer trainer) {
		// Inserting Feedback to the HashMap
		HashMap<Integer, Trainer> feedbacklist = DBUtil.getFeedback();
		feedbacklist.put(DBUtil.generateId(), trainer);
		return true;
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) {
		HashMap<Integer, Trainer> feedbacklist = DBUtil.getFeedback();

		// Adding Feedback to a new HashMap
		HashMap<Integer, Trainer> trainerlist = new HashMap<>();
		for (Entry<Integer, Trainer> feedback : feedbacklist.entrySet()) {
			if (rating == feedback.getValue().getRating()) {
				trainerlist.put(feedback.getKey(), feedback.getValue());
			}
		}
		// returning the Fetched Feedback
		return trainerlist;
	}

}
